module.exports = {
  tokens: "7732864313:AAHd1hDd45UnhOQUR2pSt47P4bPgHBugKZo",  // Masukin Bot token kamu
  owners: "7054787129", // Masukin ID Telegram kamu
  port: "2002", // Masukin Port panel kamu 
  ipvps: "http://privet.mbbstore.my.id" // Masukin IP vps kamu atau domain panel kamu yg asalnya ( https://AiiSigma.id ) menjadi ( http://AiiSigma.id )
};

/* WAJIB BACA !!!
 cari di index.js halaman 1710-1711 di situ masukin bot token sama id tele lu.

 emngnya knpa bang?
 lu buka aja dulu. di sana udah gw kasi penjelasannya
*/